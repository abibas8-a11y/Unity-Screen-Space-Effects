Shader "CustomPostProcessing/ScreenSpace"
{
    Properties
    {
        _Exposure ("Exposure", Range(-3, 3)) = 0
        _Contrast ("Contrast", Range(0, 2)) = 1.08
        _Saturation ("Saturation", Range(0, 2)) = 1.05
        _Tint ("Tint", Color) = (1,1,1,1)
        _Vignette ("Vignette", Range(0, 1)) = 0.25
        _Grain ("Grain", Range(0, 0.2)) = 0.025
        _Chromatic ("Chromatic Aberration", Range(0, 0.03)) = 0
        _PixelHeight ("Pixel Height (0 = Off)", Range(0, 1080)) = 0
        _Scanlines ("Scanlines", Range(0, 1)) = 0
        _ColorLevels ("Posterize Levels (0 = Off)", Range(0, 32)) = 0
    }
    SubShader
    {
        Tags { "RenderPipeline" = "UniversalPipeline" }
        ZWrite Off ZTest Always Cull Off
        Pass
        {
            Name "ScreenSpaceEffects"
            HLSLPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.core/Runtime/Utilities/Blit.hlsl"
            CBUFFER_START(UnityPerMaterial)
            float _Exposure, _Contrast, _Saturation, _Vignette, _Grain;
            float _Chromatic, _PixelHeight, _Scanlines, _ColorLevels;
            float4 _Tint;
            CBUFFER_END
            float4 SampleColor(float2 uv)
            {
                return SAMPLE_TEXTURE2D_X(_BlitTexture, sampler_LinearClamp, uv);
            }
            float4 Frag(Varyings input) : SV_Target
            {
                UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
                float2 uv = input.texcoord;
                float4 original = SampleColor(uv);
                float2 effectUV = uv;
                if (_PixelHeight >= 1)
                {
                    float2 grid = float2(_PixelHeight * _ScreenParams.x / _ScreenParams.y, _PixelHeight);
                    effectUV = (floor(uv * grid) + 0.5) / grid;
                }
                float3 color = SampleColor(effectUV).rgb;
                if (_Chromatic > 0)
                {
                    float2 offset = (uv - 0.5) * _Chromatic;
                    color.r = SampleColor(effectUV + offset).r;
                    color.b = SampleColor(effectUV - offset).b;
                }
                color *= exp2(_Exposure) * _Tint.rgb;
                color = (color - 0.18) * _Contrast + 0.18;
                float luminance = dot(color, float3(0.2126, 0.7152, 0.0722));
                color = lerp(luminance.xxx, color, _Saturation);
                if (_ColorLevels >= 2)
                    color = floor(saturate(color) * (floor(_ColorLevels) - 1) + 0.5) / (floor(_ColorLevels) - 1);
                float2 centered = (uv - 0.5) * 2;
                color *= 1 - smoothstep(0.15, 1.3, dot(centered, centered)) * _Vignette;
                float noise = frac(sin(dot(floor(uv * _ScreenParams.xy), float2(12.9898,78.233))
                    + floor(_Time.y * 24)) * 43758.5453) - 0.5;
                color += noise * _Grain;
                color *= 1 - (0.5 + 0.5 * cos(uv.y * _ScreenParams.y * 3.14159265)) * _Scanlines;
                return float4(max(color, 0), original.a);
            }
            ENDHLSL
        }
    }
}
