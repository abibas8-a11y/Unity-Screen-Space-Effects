Shader "CustomPassEffects/03 VHS"
{
    Properties
    {
        [Enum(VHS,0,CRT,1,DamagedTape,2)] _Style("Style", Float) = 0
        _Intensity("Intensity", Range(0,1)) = 1
        _Noise("Noise", Range(0,0.5)) = 0.07
        _ColorNoise("Color Noise", Range(0,1)) = 0.25
        _RGBShift("RGB Shift (Pixels)", Range(0,16)) = 2
        _Scanlines("Scanline Strength", Range(0,1)) = 0.16
        _ScanlineSpacing("Scanline Spacing (Pixels)", Range(2,12)) = 3
        _Jitter("Horizontal Jitter (Pixels)", Range(0,16)) = 0.6
        _Tracking("Tracking Tear (Pixels)", Range(0,120)) = 12
        _TrackingWidth("Tracking Band Width", Range(0.01,0.3)) = 0.06
        _TrackingSpeed("Tracking Speed", Range(0,2)) = 0.15
        _AnimationRate("Noise / Jitter Updates Per Second", Range(1,60)) = 24
        _Flicker("Brightness Flicker", Range(0,0.3)) = 0.025
        _Saturation("Saturation", Range(0,2)) = 0.8
        _Contrast("Contrast", Range(0.5,2)) = 1.05
        _Curvature("CRT Curvature", Range(0,0.3)) = 0.06
        _Vignette("Vignette", Range(0,1)) = 0.25
    }

    HLSLINCLUDE
    #pragma target 4.5
    #pragma vertex Vert
    #pragma multi_compile_instancing
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassCommon.hlsl"

    float _Style, _Intensity, _Noise, _ColorNoise, _RGBShift;
    float _Scanlines, _ScanlineSpacing, _Jitter, _Tracking;
    float _TrackingWidth, _TrackingSpeed, _AnimationRate, _Flicker;
    float _Saturation, _Contrast, _Curvature, _Vignette;

    float Hash(float2 p)
    {
        float3 q = frac(float3(p.x, p.y, p.x) * 0.1031);
        q += dot(q, q.yzx + 33.33);
        return frac((q.x + q.y) * q.z);
    }

    float3 ReadPixel(int2 pixel)
    {
        int2 size = max(int2(_ScreenSize.xy), int2(1, 1));
        return CustomPassLoadCustomColor((uint2)clamp(pixel, int2(0, 0), size - 1)).rgb;
    }

    // Bilinear sampling of the active viewport, independent of RTHandle allocation size.
    float3 ReadSnapshot(float2 uv)
    {
        float2 pixel = saturate(uv) * _ScreenSize.xy - 0.5;
        int2 basePixel = (int2)floor(pixel);
        float2 f = frac(pixel);
        float3 a = ReadPixel(basePixel);
        float3 b = ReadPixel(basePixel + int2(1, 0));
        float3 c = ReadPixel(basePixel + int2(0, 1));
        float3 d = ReadPixel(basePixel + int2(1, 1));
        return lerp(lerp(a, b, f.x), lerp(c, d, f.x), f.y);
    }

    float4 CopyScene(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        return float4(CustomPassLoadCameraColor((uint2)input.positionCS.xy, 0), 1);
    }

    float4 VHS(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        float3 original = ReadPixel((int2)input.positionCS.xy);
        float weight = saturate(_Intensity) * saturate(_FadeValue);
        if (weight <= 0.0) return float4(original, 1);

        float2 uv = input.positionCS.xy * _ScreenSize.zw;
        float2 centered = uv * 2.0 - 1.0;
        bool crt = _Style > 0.5 && _Style < 1.5;
        bool damaged = _Style > 1.5;
        float damage = damaged ? 2.0 : (crt ? 0.25 : 1.0);
        float time = _Time.y;
        float frame = floor(time * max(_AnimationRate, 1.0));

        if (crt)
        {
            float2 bent = centered * (1.0 + dot(centered, centered) * _Curvature);
            uv = bent * 0.5 + 0.5;
        }

        float row = floor(input.positionCS.y / 3.0);
        float jitterPixels = (Hash(float2(row, frame)) - 0.5) * 2.0 * _Jitter * damage;
        float bandCenter = frac(time * _TrackingSpeed + 0.3);
        float bandDistance = abs(uv.y - bandCenter);
        bandDistance = min(bandDistance, 1.0 - bandDistance);
        float band = 1.0 - smoothstep(0.0, max(_TrackingWidth, 0.001), bandDistance);
        float tearPixels = band * _Tracking * damage *
            (0.5 + 0.5 * sin(uv.y * 95.0 + time * 7.0));
        uv.x += (jitterPixels + tearPixels) * _ScreenSize.z;

        float split = _RGBShift * (damaged ? 1.8 : 1.0) * _ScreenSize.z;
        float3 sampled;
        sampled.r = ReadSnapshot(uv + float2(split, 0)).r;
        sampled.g = ReadSnapshot(uv).g;
        sampled.b = ReadSnapshot(uv - float2(split, 0)).b;
        float3 color = LinearToSRGB(saturate(sampled));

        float luma = dot(color, float3(0.2126, 0.7152, 0.0722));
        color = lerp(luma.xxx, color, _Saturation);
        color = (color - 0.5) * _Contrast + 0.5;

        float2 pixel = floor(input.positionCS.xy);
        float monoNoise = Hash(pixel + float2(frame * 17.0, frame * 3.0)) - 0.5;
        float3 rgbNoise = float3(
            monoNoise,
            Hash(pixel + float2(frame * 11.0 + 41.0, frame * 5.0)) - 0.5,
            Hash(pixel + float2(frame * 7.0, frame * 13.0 + 19.0)) - 0.5);
        float3 noise = lerp(monoNoise.xxx, rgbNoise, saturate(_ColorNoise));
        color += noise * _Noise * (damaged ? 2.0 : 1.0);

        float spacing = max(_ScanlineSpacing, 2.0);
        float linePhase = input.positionCS.y * TWO_PI / spacing;
        // Fade scanlines near their pixel Nyquist limit to reduce aliasing.
        float attenuation = saturate(1.0 - fwidth(linePhase) / TWO_PI);
        float scan = 0.5 + 0.5 * cos(linePhase);
        color *= 1.0 - scan * attenuation * saturate(_Scanlines);
        color *= 1.0 + (Hash(float2(frame, 73.0)) - 0.5) * 2.0 * _Flicker;
        float vignette = smoothstep(0.2, 1.8, dot(centered, centered));
        color *= 1.0 - vignette * saturate(_Vignette);

        // Curved CRT corners and tracking excursions outside the image are black.
        float inside = step(0.0, uv.x) * step(uv.x, 1.0) * step(0.0, uv.y) * step(uv.y, 1.0);
        color = saturate(color) * inside;
        return float4(lerp(original, SRGBToLinear(color), weight), 1);
    }
    ENDHLSL

    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }
        ZWrite Off
        ZTest Always
        Cull Off
        Blend Off
        ColorMask RGB
        Pass
        {
            Name "Copy Scene"
            HLSLPROGRAM
            #pragma fragment CopyScene
            ENDHLSL
        }
        Pass
        {
            Name "VHS"
            HLSLPROGRAM
            #pragma fragment VHS
            ENDHLSL
        }
    }
    Fallback Off
}
