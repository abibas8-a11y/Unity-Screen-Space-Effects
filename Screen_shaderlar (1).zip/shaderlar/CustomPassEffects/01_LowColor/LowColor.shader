Shader "CustomPassEffects/01 Low Color"
{
    Properties
    {
        [Enum(RGB,0,Grayscale,1)] _ColorMode("Color Mode", Float) = 0
        [Enum(Two,2,Four,4,Eight,8,Sixteen,16,ThirtyTwo,32,SixtyFour,64)] _Levels("Levels Per Channel", Float) = 8
        [Toggle] _SeparateChannels("Separate RGB Levels", Float) = 0
        [Enum(Two,2,Four,4,Eight,8,Sixteen,16,ThirtyTwo,32,SixtyFour,64)] _RedLevels("Red Levels", Float) = 8
        [Enum(Two,2,Four,4,Eight,8,Sixteen,16,ThirtyTwo,32,SixtyFour,64)] _GreenLevels("Green Levels", Float) = 8
        [Enum(Two,2,Four,4,Eight,8,Sixteen,16,ThirtyTwo,32,SixtyFour,64)] _BlueLevels("Blue Levels", Float) = 8
        [Toggle] _RedEnabled("Red Channel", Float) = 1
        [Toggle] _GreenEnabled("Green Channel", Float) = 1
        [Toggle] _BlueEnabled("Blue Channel", Float) = 1
        _Dither("Ordered Dither", Range(0,1)) = 0
        _Intensity("Intensity", Range(0,1)) = 1
    }
    HLSLINCLUDE
    #pragma target 4.5
    #pragma vertex Vert
    #pragma fragment FullScreenPass
    #pragma multi_compile_instancing
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassCommon.hlsl"

    float _ColorMode, _Levels, _SeparateChannels;
    float _RedLevels, _GreenLevels, _BlueLevels;
    float _RedEnabled, _GreenEnabled, _BlueEnabled;
    float _Dither, _Intensity;

    float Bayer4(uint2 pixel)
    {
        // 4x4 Bayer matrix, computed without dynamic array indexing.
        uint2 p = pixel & 3u;
        uint low = ((p.x & 1u) ^ (p.y & 1u)) * 2u + (p.y & 1u);
        uint high = (((p.x >> 1u) & 1u) ^ ((p.y >> 1u) & 1u)) * 2u + ((p.y >> 1u) & 1u);
        return (float(low * 4u + high) + 0.5) / 16.0 - 0.5;
    }

    float4 FullScreenPass(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        float3 original = CustomPassLoadCameraColor((uint2)input.positionCS.xy, 0);
        // Quantize in display-like sRGB space, then return to linear output.
        // Intended for After Post Process, where tone mapping has already run.
        float3 color = LinearToSRGB(saturate(original));
        float3 levels = _SeparateChannels > 0.5
            ? float3(_RedLevels, _GreenLevels, _BlueLevels) : _Levels.xxx;
        if (_ColorMode > 0.5)
        {
            float gray = dot(color, float3(0.2126, 0.7152, 0.0722));
            color = gray.xxx;
            levels = _Levels.xxx;
        }
        float3 steps = max(round(levels), 2.0) - 1.0;
        float threshold = Bayer4((uint2)input.positionCS.xy) * saturate(_Dither);
        color = floor(saturate(color + threshold / steps) * steps + 0.5) / steps;
        color *= step(0.5, float3(_RedEnabled, _GreenEnabled, _BlueEnabled));
        float weight = saturate(_Intensity) * saturate(_FadeValue);
        return float4(lerp(original, SRGBToLinear(color), weight), 1);
    }
    ENDHLSL
    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }
        Pass
        {
            Name "Low Color"
            ZWrite Off
            ZTest Always
            Cull Off
            Blend Off
            ColorMask RGB
            HLSLPROGRAM
            ENDHLSL
        }
    }
    Fallback Off
}
