Shader "CustomPassEffects/11 Watercolor"
{
    Properties
    {
        [Enum(Watercolor,0,InkSketch,1,ColorWash,2)] _Style("Style", Float) = 0
        _Intensity("Intensity", Range(0,1)) = 1
        _BrushRadius("Brush / Edge Radius (Pixels)", Range(1,12)) = 3
        _Bleed("Color Spread Strength", Range(0,1)) = 0.75
        _Warp("Paper Warp (Pixels)", Range(0,8)) = 0.6
        _Saturation("Saturation", Range(0,2)) = 0.85
        _Washout("Paper Washout", Range(0,1)) = 0.15
        [Enum(Four,4,Eight,8,Sixteen,16,ThirtyTwo,32)] _Levels("Pigment Levels", Float) = 8
        _Posterize("Pigment Posterization", Range(0,1)) = 0.4
        _InkColor("Ink Color", Color) = (0.045,0.035,0.055,1)
        _InkStrength("Ink Outline Strength", Range(0,1)) = 0.6
        _InkThreshold("Ink Edge Threshold", Range(0.005,1)) = 0.1
        _InkSoftness("Ink Edge Softness", Range(0.001,0.5)) = 0.08
        _PigmentEdges("Pigment Edge Darkening", Range(0,1)) = 0.3
        _PaperColor("Paper Color", Color) = (1,0.95,0.86,1)
        _PaperStrength("Paper Grain Strength", Range(0,0.5)) = 0.12
        _PaperScale("Paper Grain Density", Range(10,400)) = 180
        _PigmentNoise("Uneven Pigment Strength", Range(0,0.5)) = 0.12
        _Seed("Texture Seed", Range(0,100)) = 0
    }

    HLSLINCLUDE
    #pragma target 4.5
    #pragma vertex Vert
    #pragma multi_compile_instancing
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassCommon.hlsl"

    float _Style, _Intensity, _BrushRadius, _Bleed, _Warp, _Saturation, _Washout;
    float _Levels, _Posterize, _InkStrength, _InkThreshold, _InkSoftness, _PigmentEdges;
    float _PaperStrength, _PaperScale, _PigmentNoise, _Seed;
    float4 _InkColor, _PaperColor;

    float PaintHash(float2 p)
    {
        float3 q = frac(float3(p.x, p.y, p.x) * 0.1031);
        q += dot(q, q.yzx + 33.33);
        return frac((q.x + q.y) * q.z);
    }

    float PaintNoise(float2 p)
    {
        float2 b = floor(p), f = frac(p);
        float2 u = f * f * (3.0 - 2.0 * f);
        return lerp(lerp(PaintHash(b), PaintHash(b + float2(1, 0)), u.x),
            lerp(PaintHash(b + float2(0, 1)), PaintHash(b + float2(1, 1)), u.x), u.y);
    }

    float3 PaintPixel(int2 pixel)
    {
        int2 size = max(int2(_ScreenSize.xy), int2(1, 1));
        return CustomPassLoadCustomColor((uint2)clamp(pixel, int2(0, 0), size - 1)).rgb;
    }

    float3 PaintSample(float2 uv)
    {
        float2 p = saturate(uv) * _ScreenSize.xy - 0.5;
        int2 b = (int2)floor(p);
        float2 f = frac(p);
        float3 linearColor = lerp(
            lerp(PaintPixel(b), PaintPixel(b + int2(1, 0)), f.x),
            lerp(PaintPixel(b + int2(0, 1)), PaintPixel(b + int2(1, 1)), f.x), f.y);
        return LinearToSRGB(saturate(linearColor));
    }

    void PaintRegion(float3 a, float3 b, float3 c, float3 d, inout float bestVariance, inout float3 result)
    {
        float3 mean = (a + b + c + d) * 0.25;
        float3 variance = max((a*a + b*b + c*c + d*d) * 0.25 - mean*mean, 0.0);
        float total = variance.r + variance.g + variance.b;
        if (total < bestVariance) { bestVariance = total; result = mean; }
    }

    float4 CopyScene(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        return float4(CustomPassLoadCameraColor((uint2)input.positionCS.xy, 0), 1);
    }

    float4 Watercolor(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        float3 original = PaintPixel((int2)input.positionCS.xy);
        float weight = saturate(_Intensity) * saturate(_FadeValue);
        if (weight <= 0.0) return float4(original, 1);

        float2 screenUV = input.positionCS.xy * _ScreenSize.zw;
        float aspect = _ScreenSize.x / max(_ScreenSize.y, 1.0);
        float2 paperUV = screenUV * float2(aspect, 1);
        float broad = PaintNoise(paperUV * 13.0 + _Seed);
        float fine = PaintNoise(paperUV * _PaperScale + _Seed * 3.1);
        float2 offset = float2(broad, PaintNoise(paperUV * 13.0 + _Seed + 29.0)) * 2.0 - 1.0;
        float2 uv = screenUV + offset * _Warp * _ScreenSize.zw;
        float2 stepUV = max(_BrushRadius, 1.0) * _ScreenSize.zw;

        float3 center = PaintSample(uv);
        float3 tl = PaintSample(uv - stepUV);
        float3 tc = PaintSample(uv - float2(0, stepUV.y));
        float3 tr = PaintSample(uv + float2(stepUV.x, -stepUV.y));
        float3 ml = PaintSample(uv - float2(stepUV.x, 0));
        float3 mr = PaintSample(uv + float2(stepUV.x, 0));
        float3 bl = PaintSample(uv + float2(-stepUV.x, stepUV.y));
        float3 bc = PaintSample(uv + float2(0, stepUV.y));
        float3 br = PaintSample(uv + stepUV);

        // Sparse four-quadrant Kuwahara-like smoothing favors the least varied region.
        float best = 100.0;
        float3 filtered = center;
        PaintRegion(center, ml, tc, tl, best, filtered);
        PaintRegion(center, mr, tc, tr, best, filtered);
        PaintRegion(center, ml, bc, bl, best, filtered);
        PaintRegion(center, mr, bc, br, best, filtered);
        float3 color = lerp(center, filtered, saturate(_Bleed));

        float3 gx = -tl - 2.0*ml - bl + tr + 2.0*mr + br;
        float3 gy = -tl - 2.0*tc - tr + bl + 2.0*bc + br;
        float edge = sqrt(dot(gx, gx) + dot(gy, gy)) * 0.144337567;
        float inkMask = smoothstep(_InkThreshold, _InkThreshold + max(_InkSoftness, 0.001), edge);
        float gray = dot(color, float3(0.2126, 0.7152, 0.0722));
        bool sketch = _Style > 0.5 && _Style < 1.5;
        bool wash = _Style > 1.5;
        float3 paper = LinearToSRGB(saturate(_PaperColor.rgb));
        float3 ink = LinearToSRGB(saturate(_InkColor.rgb));
        float steps = max(floor(_Levels + 0.5), 2.0) - 1.0;
        if (sketch)
        {
            float shade = lerp(gray, floor(gray * steps + 0.5) / steps, saturate(_Posterize));
            color = lerp(ink, paper, shade);
        }
        else
        {
            color = saturate(lerp(gray.xxx, color, _Saturation));
            float3 reduced = floor(color * steps + 0.5) / steps;
            color = lerp(color, reduced, saturate(_Posterize));
            color *= paper;
        }
        color = lerp(color, paper, saturate(_Washout));
        float pigment = (1.0 - gray) * (1.0 - broad) * _PigmentNoise;
        color *= 1.0 - pigment;
        color *= 1.0 - inkMask * _PigmentEdges * (wash ? 0.4 : 1.0);
        color = lerp(color, ink, inkMask * _InkStrength * (wash ? 0.25 : 1.0));
        color *= 1.0 + (fine * 2.0 - 1.0) * _PaperStrength;
        return float4(lerp(original, SRGBToLinear(saturate(color)), weight), 1);
    }
    ENDHLSL

    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }
        ZWrite Off
        ZTest Always
        Cull Off
        Blend Off
        ColorMask RGB
        Pass
        {
            Name "Copy Scene"
            HLSLPROGRAM
            #pragma fragment CopyScene
            ENDHLSL
        }
        Pass
        {
            Name "Watercolor"
            HLSLPROGRAM
            #pragma fragment Watercolor
            ENDHLSL
        }
    }
    Fallback Off
}
