Shader "CustomPassEffects/12 Normal Etching"
{
    Properties
    {
        [Enum(EtchedSurface,0,Clay,1,NormalView,2)] _Style("Style", Float) = 0
        _Intensity("Intensity", Range(0,1)) = 1
        _Opacity("Surface Overlay Opacity", Range(0,1)) = 1
        _SurfaceColor("Surface Color", Color) = (0.85,0.94,1,1)
        _ShadowColor("Shadow Color", Color) = (0.12,0.22,0.32,1)
        _InkColor("Line Color", Color) = (0.015,0.035,0.06,1)
        _LightDirection("Artistic Light Direction (World XYZ)", Vector) = (0.4,0.8,0.3,0)
        [Enum(Two,2,Four,4,Eight,8,Sixteen,16)] _Bands("Normal Shading Bands", Float) = 4
        _BandStrength("Shading Band Strength", Range(0,1)) = 0.8
        _HatchStrength("Surface Hatch Strength", Range(0,1)) = 0.65
        _HatchSpacing("Hatch Spacing (World Units)", Range(0.02,2)) = 0.15
        _HatchWidth("Hatch Line Width (Fraction)", Range(0.02,0.4)) = 0.1
        _HatchShadow("Hatch Shadow Threshold", Range(0.05,1)) = 0.7
        _EdgeStrength("Normal Edge Strength", Range(0,1)) = 1
        _EdgeWidth("Edge Sample Radius (Pixels)", Range(1,5)) = 1
        _CreaseAngle("Normal Edge Angle (Degrees)", Range(1,90)) = 15
    }

    HLSLINCLUDE
    #pragma target 4.5
    #pragma vertex Vert
    #pragma multi_compile_instancing
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassCommon.hlsl"
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/Material/NormalBuffer.hlsl"

    float _Style, _Intensity, _Opacity, _Bands, _BandStrength;
    float _HatchStrength, _HatchSpacing, _HatchWidth, _HatchShadow;
    float _EdgeStrength, _EdgeWidth, _CreaseAngle;
    float4 _SurfaceColor, _ShadowColor, _InkColor, _LightDirection;

    uint2 EtchPixel(int2 pixel)
    {
        int2 size = max(int2(_ScreenSize.xy), int2(1, 1));
        return (uint2)clamp(pixel, int2(0, 0), size - 1);
    }

    bool EtchSky(float depth)
    {
        #if UNITY_REVERSED_Z
            return depth <= 0.0000001;
        #else
            return depth >= 0.9999999;
        #endif
    }

    float EtchNormalDifference(int2 pixel, float3 centerNormal)
    {
        uint2 samplePixel = EtchPixel(pixel);
        if (EtchSky(CustomPassLoadCameraDepth(samplePixel))) return 1.0;
        NormalData data;
        DecodeFromNormalBuffer(samplePixel, data);
        float3 neighbor = data.normalWS / max(length(data.normalWS), 0.0001);
        return 1.0 - clamp(dot(centerNormal, neighbor), -1.0, 1.0);
    }

    float EtchLine(float coordinate)
    {
        float spacing = max(_HatchSpacing, 0.001);
        float scaled = coordinate / spacing;
        float aa = max(fwidth(scaled), 0.001);
        float distanceToLine = abs(frac(scaled + 0.5) - 0.5);
        float hatchLine = 1.0 - smoothstep(_HatchWidth * 0.5, _HatchWidth * 0.5 + aa, distanceToLine);
        // Suppress lines too dense to resolve in the current viewport.
        return hatchLine * (1.0 - smoothstep(0.35, 1.0, aa));
    }

    float4 NormalEtching(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        float alpha = saturate(_Intensity) * saturate(_Opacity) * saturate(_FadeValue);
        // The normal buffer is not guaranteed at After Post Process.
        // Invalid placement draws a transparent overlay instead of stale data.
        if (_CustomPassInjectionPoint != CUSTOMPASSINJECTIONPOINT_BEFORE_POST_PROCESS || alpha <= 0.0)
            return float4(0, 0, 0, 0);
        uint2 pixel = EtchPixel((int2)input.positionCS.xy);
        float depth = CustomPassLoadCameraDepth(pixel);
        if (EtchSky(depth)) return float4(0, 0, 0, 0);

        NormalData data;
        DecodeFromNormalBuffer(pixel, data);
        float magnitude = length(data.normalWS);
        if (magnitude < 0.0001) return float4(0, 0, 0, 0);
        float3 normalWS = data.normalWS / magnitude;
        if (_Style > 1.5)
            return float4(normalWS * 0.5 + 0.5, alpha);

        float3 light = _LightDirection.xyz;
        light = dot(light, light) < 0.0001 ? float3(0, 1, 0) : normalize(light);
        float shade = saturate(dot(normalWS, light));
        float steps = max(floor(_Bands + 0.5), 2.0) - 1.0;
        float banded = floor(shade * steps + 0.5) / steps;
        shade = lerp(shade, banded, saturate(_BandStrength));
        float3 color = lerp(_ShadowColor.rgb, _SurfaceColor.rgb, shade);

        if (_Style < 0.5 && _HatchStrength > 0.0)
        {
            PositionInputs position = GetPositionInput(input.positionCS.xy, _ScreenSize.zw,
                depth, UNITY_MATRIX_I_VP, UNITY_MATRIX_V);
            float3 world = GetAbsolutePositionWS(position.positionWS);
            // World projection blends according to the actual surface normal.
            float3 axisWeights = pow(abs(normalWS), 4.0);
            axisWeights /= max(axisWeights.x + axisWeights.y + axisWeights.z, 0.0001);
            float3 hatches = float3(EtchLine(world.y + world.z * 0.65),
                EtchLine(world.x - world.z * 0.65), EtchLine(world.x + world.y * 0.65));
            float hatch = dot(axisWeights, hatches);
            float shadowMask = 1.0 - smoothstep(0.0, max(_HatchShadow, 0.001), shade);
            color = lerp(color, _InkColor.rgb, hatch * shadowMask * _HatchStrength);
        }

        if (_EdgeStrength > 0.0)
        {
            int width = max((int)floor(_EdgeWidth + 0.5), 1);
            float difference = EtchNormalDifference((int2)pixel + int2(width, 0), normalWS);
            difference = max(difference, EtchNormalDifference((int2)pixel - int2(width, 0), normalWS));
            difference = max(difference, EtchNormalDifference((int2)pixel + int2(0, width), normalWS));
            difference = max(difference, EtchNormalDifference((int2)pixel - int2(0, width), normalWS));
            float threshold = 1.0 - cos(radians(_CreaseAngle));
            float edge = smoothstep(threshold, threshold * 1.5 + 0.0001, difference);
            color = lerp(color, _InkColor.rgb, edge * _EdgeStrength);
        }
        return float4(max(color, 0.0), alpha);
    }
    ENDHLSL

    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }
        Pass
        {
            Name "Normal Etching"
            ZWrite Off
            ZTest Always
            Cull Off
            Blend SrcAlpha OneMinusSrcAlpha
            ColorMask RGB
            HLSLPROGRAM
            #pragma fragment NormalEtching
            ENDHLSL
        }
    }
    Fallback Off
}
