Shader "CustomPassEffects/10 Frost"
{
    Properties
    {
        [Enum(Hoarfrost,0,CrackedIce,1,DeepFreeze,2)] _Style("Style", Float) = 0
        _Intensity("Intensity", Range(0,1)) = 1
        _Coverage("Ice Coverage", Range(0,1)) = 0.5
        _EdgeSoftness("Freeze Front Softness", Range(0.01,0.4)) = 0.1
        _EdgeRoughness("Freeze Front Roughness", Range(0,0.4)) = 0.15
        _PatternScale("Ice Cell Density", Range(4,100)) = 32
        _Seed("Pattern Seed", Range(0,100)) = 0
        _IceColor("Ice Color", Color) = (0.65,0.86,1,1)
        _Opacity("Ice Opacity", Range(0,1)) = 0.6
        _CrystalStrength("Crystal Texture Strength", Range(0,1)) = 0.55
        _CrackStrength("Crack Strength", Range(0,1)) = 0.55
        _CrackWidth("Crack Width (Cell Units)", Range(0.005,0.15)) = 0.025
        _Refraction("Refraction (Pixels)", Range(0,30)) = 6
        _BlurRadius("Ice Blur Radius (Pixels)", Range(0,12)) = 3
        _BlurStrength("Ice Blur Strength", Range(0,1)) = 0.45
        _Desaturation("Ice Desaturation", Range(0,1)) = 0.25
        [Toggle] _AutoFreeze("Freeze / Thaw Preview", Float) = 0
        _PreviewSpeed("Preview Cycles Per Second", Range(0.01,1)) = 0.08
    }

    HLSLINCLUDE
    #pragma target 4.5
    #pragma vertex Vert
    #pragma multi_compile_instancing
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassCommon.hlsl"

    float _Style, _Intensity, _Coverage, _EdgeSoftness, _EdgeRoughness, _PatternScale, _Seed;
    float4 _IceColor;
    float _Opacity, _CrystalStrength, _CrackStrength, _CrackWidth, _Refraction;
    float _BlurRadius, _BlurStrength, _Desaturation, _AutoFreeze, _PreviewSpeed;

    float2 FrostHash(float2 p)
    {
        float3 q = frac(float3(p.x, p.y, p.x) * float3(0.1031, 0.1030, 0.0973));
        q += dot(q, q.yzx + 33.33);
        return frac((q.xx + q.yz) * q.zy);
    }

    float FrostNoise(float2 p)
    {
        float2 cell = floor(p), f = frac(p);
        float2 u = f * f * (3.0 - 2.0 * f);
        return lerp(lerp(FrostHash(cell).x, FrostHash(cell + float2(1, 0)).x, u.x),
            lerp(FrostHash(cell + float2(0, 1)).x, FrostHash(cell + float2(1, 1)).x, u.x), u.y);
    }

    void FrostCells(float2 p, out float nearest, out float gap, out float2 direction)
    {
        float2 baseCell = floor(p), f = frac(p);
        float first = 100.0, second = 100.0;
        direction = float2(0, 0);
        [unroll] for (int y = -1; y <= 1; y++)
        {
            [unroll] for (int x = -1; x <= 1; x++)
            {
                float2 offset = float2(x, y);
                // Jitter is constrained so a 3x3 neighborhood captures the nearest cells.
                float2 seed = 0.5 + (FrostHash(baseCell + offset + _Seed) - 0.5) * 0.7;
                float2 delta = offset + seed - f;
                float d = dot(delta, delta);
                if (d < first) { second = first; first = d; direction = delta; }
                else second = min(second, d);
            }
        }
        nearest = sqrt(max(first, 0.0));
        gap = sqrt(max(second, 0.0)) - nearest;
    }

    float3 FrostPixel(int2 pixel)
    {
        int2 size = max(int2(_ScreenSize.xy), int2(1, 1));
        return CustomPassLoadCustomColor((uint2)clamp(pixel, int2(0, 0), size - 1)).rgb;
    }

    float3 FrostSample(float2 uv)
    {
        float2 p = saturate(uv) * _ScreenSize.xy - 0.5;
        int2 b = (int2)floor(p);
        float2 f = frac(p);
        return lerp(
            lerp(FrostPixel(b), FrostPixel(b + int2(1, 0)), f.x),
            lerp(FrostPixel(b + int2(0, 1)), FrostPixel(b + int2(1, 1)), f.x), f.y);
    }

    float4 CopyScene(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        return float4(CustomPassLoadCameraColor((uint2)input.positionCS.xy, 0), 1);
    }

    float4 Frost(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        float3 original = FrostPixel((int2)input.positionCS.xy);
        float coverage = saturate(_Coverage);
        if (_AutoFreeze > 0.5)
            coverage *= 0.5 - 0.5 * cos(_Time.y * _PreviewSpeed * TWO_PI);
        float weight = saturate(_Intensity) * saturate(_FadeValue);
        if (weight <= 0.0 || coverage <= 0.0) return float4(original, 1);

        float2 uv = input.positionCS.xy * _ScreenSize.zw;
        float aspect = _ScreenSize.x / max(_ScreenSize.y, 1.0);
        float2 p = uv * float2(aspect, 1.0);
        float noise = FrostNoise(p * 7.0 + _Seed);
        float2 border = min(uv, 1.0 - uv) * 2.0;
        float edgeDepth = min(border.x, border.y);
        float front = coverage * 1.3 - 0.15;
        float roughDepth = edgeDepth + (noise - 0.5) * _EdgeRoughness;
        float mask = 1.0 - smoothstep(front - _EdgeSoftness, front + _EdgeSoftness, roughDepth);
        // Exact endpoints; avoid a partially frozen border at zero coverage.
        mask *= smoothstep(0.0, 0.08, coverage);
        if (coverage >= 0.9999) mask = 1.0;

        float nearest, gap;
        float2 direction;
        FrostCells(p * _PatternScale, nearest, gap, direction);
        float aa = max(fwidth(gap), 0.001);
        float cracks = 1.0 - smoothstep(_CrackWidth, _CrackWidth + aa, gap);
        bool cracked = _Style > 0.5 && _Style < 1.5;
        bool frozen = _Style > 1.5;
        float crackScale = cracked ? 1.0 : 0.55;
        float crystal = saturate(0.55 * noise + 0.45 * (1.0 - nearest));
        float2 normal = direction / max(length(direction), 0.001);
        float2 refractedUV = uv + normal * _Refraction * mask * _ScreenSize.zw;
        float3 color = FrostSample(refractedUV);
        if (_BlurRadius > 0.0 && _BlurStrength > 0.0)
        {
            float2 delta = _BlurRadius * _ScreenSize.zw;
            float3 soft = color * 0.4;
            soft += FrostSample(refractedUV + float2(delta.x, 0)) * 0.15;
            soft += FrostSample(refractedUV - float2(delta.x, 0)) * 0.15;
            soft += FrostSample(refractedUV + float2(0, delta.y)) * 0.15;
            soft += FrostSample(refractedUV - float2(0, delta.y)) * 0.15;
            color = lerp(color, soft, saturate(_BlurStrength));
        }
        float luma = dot(color, float3(0.2126, 0.7152, 0.0722));
        color = lerp(color, luma.xxx, saturate(_Desaturation));
        float opacity = saturate(_Opacity * (frozen ? 1.3 : (cracked ? 0.65 : 1.0)));
        float3 ice = saturate(_IceColor.rgb) * lerp(0.65, 1.2, crystal * _CrystalStrength);
        color = lerp(color, ice, opacity);
        color = lerp(color, saturate(_IceColor.rgb), cracks * _CrackStrength * crackScale);
        // Everything, including refraction and blur, is confined to the frost mask.
        return float4(lerp(original, saturate(color), mask * weight), 1);
    }
    ENDHLSL

    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }
        ZWrite Off
        ZTest Always
        Cull Off
        Blend Off
        ColorMask RGB
        Pass
        {
            Name "Copy Scene"
            HLSLPROGRAM
            #pragma fragment CopyScene
            ENDHLSL
        }
        Pass
        {
            Name "Frost"
            HLSLPROGRAM
            #pragma fragment Frost
            ENDHLSL
        }
    }
    Fallback Off
}
