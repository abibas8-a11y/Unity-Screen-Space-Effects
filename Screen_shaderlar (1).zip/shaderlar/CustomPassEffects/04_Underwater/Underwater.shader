Shader "CustomPassEffects/04 Underwater"
{
    Properties
    {
        [Enum(Shallow,0,Deep,1,Murky,2)] _Style("Water Style", Float) = 0
        _Intensity("Intensity", Range(0,1)) = 1
        _WaterColor("Water Color", Color) = (0.04,0.42,0.5,1)
        _TintStrength("Near Water Tint", Range(0,1)) = 0.15
        _Visibility("Visibility Distance (Half Transmission)", Range(1,200)) = 25
        _FogStart("Fog Start Distance", Range(0,50)) = 0
        _FogStrength("Fog Strength", Range(0,1)) = 0.85
        _Absorption("RGB Absorption Per Unit", Vector) = (0.045,0.012,0.006,0)
        _AbsorptionStrength("Absorption Strength", Range(0,2)) = 0.6
        _DistortionPixels("Wave Distortion (Pixels)", Range(0,30)) = 3
        _WaveFrequency("Wave Frequency", Range(1,80)) = 22
        _WaveSpeed("Wave Speed", Range(0,4)) = 0.7
        _BlurRadius("Far Blur Radius (Pixels)", Range(0,8)) = 2
        _BlurStrength("Far Blur Strength", Range(0,1)) = 0.5
        _Vignette("Vignette", Range(0,1)) = 0.2
    }

    HLSLINCLUDE
    #pragma target 4.5
    #pragma vertex Vert
    #pragma multi_compile_instancing
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassCommon.hlsl"

    float _Style, _Intensity;
    float4 _WaterColor, _Absorption;
    float _TintStrength, _Visibility, _FogStart, _FogStrength, _AbsorptionStrength;
    float _DistortionPixels, _WaveFrequency, _WaveSpeed, _BlurRadius, _BlurStrength, _Vignette;

    float3 WaterReadPixel(int2 pixel)
    {
        int2 size = max(int2(_ScreenSize.xy), int2(1, 1));
        return CustomPassLoadCustomColor((uint2)clamp(pixel, int2(0, 0), size - 1)).rgb;
    }

    float3 WaterRead(float2 uv)
    {
        float2 p = saturate(uv) * _ScreenSize.xy - 0.5;
        int2 basePixel = (int2)floor(p);
        float2 f = frac(p);
        float3 a = lerp(WaterReadPixel(basePixel), WaterReadPixel(basePixel + int2(1, 0)), f.x);
        float3 b = lerp(WaterReadPixel(basePixel + int2(0, 1)), WaterReadPixel(basePixel + int2(1, 1)), f.x);
        return lerp(a, b, f.y);
    }

    float WaterEyeDepth(float2 uv)
    {
        int2 size = max(int2(_ScreenSize.xy), int2(1, 1));
        uint2 pixel = (uint2)clamp((int2)(saturate(uv) * _ScreenSize.xy), int2(0, 0), size - 1);
        // HDRP helper applies the After Post Process dynamic-resolution depth scale.
        float raw = CustomPassLoadCameraDepth(pixel);
        if (unity_OrthoParams.w > 0.5)
        {
            #if UNITY_REVERSED_Z
                raw = 1.0 - raw;
            #endif
            return lerp(_ProjectionParams.y, _ProjectionParams.z, raw);
        }
        return min(LinearEyeDepth(raw, _ZBufferParams), _ProjectionParams.z);
    }

    float4 CopyScene(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        return float4(CustomPassLoadCameraColor((uint2)input.positionCS.xy, 0), 1);
    }

    float4 Underwater(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        float3 original = WaterReadPixel((int2)input.positionCS.xy);
        float weight = saturate(_Intensity) * saturate(_FadeValue);
        if (weight <= 0.0) return float4(original, 1);

        float2 screenUV = input.positionCS.xy * _ScreenSize.zw;
        float time = _Time.y * _WaveSpeed;
        float2 phase = screenUV * _WaveFrequency;
        float2 wave = float2(
            sin(phase.y + time * 1.7) + 0.35 * sin(phase.x * 0.7 - time * 1.1),
            cos(phase.x * 0.8 + time * 1.3) + 0.35 * sin(phase.y * 1.2 + time));
        float2 uv = saturate(screenUV + wave / 1.35 * _DistortionPixels * _ScreenSize.zw);

        bool deep = _Style > 0.5 && _Style < 1.5;
        bool murky = _Style > 1.5;
        float visibility = max(_Visibility * (deep ? 0.65 : (murky ? 0.35 : 1.0)), 0.1);
        float distance = max(WaterEyeDepth(uv) - _FogStart, 0.0);
        float fog = saturate(1.0 - exp2(-distance / visibility));
        float blur = saturate(fog * _BlurStrength * (murky ? 1.5 : 1.0));
        float3 color = WaterRead(uv);
        if (_BlurRadius > 0.0 && blur > 0.0)
        {
            float2 radius = _BlurRadius * fog * _ScreenSize.zw;
            float3 soft = color * 0.4;
            soft += WaterRead(uv + float2(radius.x, 0)) * 0.15;
            soft += WaterRead(uv - float2(radius.x, 0)) * 0.15;
            soft += WaterRead(uv + float2(0, radius.y)) * 0.15;
            soft += WaterRead(uv - float2(0, radius.y)) * 0.15;
            color = lerp(color, soft, blur);
        }

        float3 water = saturate(_WaterColor.rgb);
        if (deep) water *= float3(0.55, 0.75, 0.95);
        if (murky) water *= float3(1.15, 0.95, 0.65);
        float3 transmission = exp(-min(distance, 10000.0) * max(_Absorption.rgb, 0.0)
            * _AbsorptionStrength * (deep ? 1.5 : 1.0));
        color *= transmission;
        color *= lerp(float3(1, 1, 1), saturate(water + 0.35), saturate(_TintStrength));
        color = lerp(color, water, fog * saturate(_FogStrength));

        float2 centered = screenUV * 2.0 - 1.0;
        float vignette = smoothstep(0.2, 1.8, dot(centered, centered));
        color *= 1.0 - vignette * saturate(_Vignette);
        return float4(lerp(original, color, weight), 1);
    }
    ENDHLSL

    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }
        ZWrite Off
        ZTest Always
        Cull Off
        Blend Off
        ColorMask RGB
        Pass
        {
            Name "Copy Scene"
            HLSLPROGRAM
            #pragma fragment CopyScene
            ENDHLSL
        }
        Pass
        {
            Name "Underwater"
            HLSLPROGRAM
            #pragma fragment Underwater
            ENDHLSL
        }
    }
    Fallback Off
}
