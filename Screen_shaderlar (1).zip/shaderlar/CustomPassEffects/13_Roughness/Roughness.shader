Shader "CustomPassEffects/13 Roughness Coating"
{
    Properties
    {
        [Enum(Coating,0,RoughnessView,1,SelectionMask,2)] _View("View", Float) = 0
        [Enum(SmoothSurfaces,0,RoughSurfaces,1,AllSurfaces,2)] _Target("Target Surfaces", Float) = 0
        _Intensity("Intensity", Range(0,1)) = 1
        _Threshold("Perceptual Roughness Threshold", Range(0,1)) = 0.45
        _Softness("Selection Softness", Range(0.01,0.5)) = 0.15
        _Darkening("Selected Surface Darkening", Range(0,0.9)) = 0.35
        _Tint("Coating Tint", Color) = (0.08,0.3,0.42,1)
        _TintStrength("Tint Addition", Range(0,2)) = 0.2
        _GlintColor("Highlight Color", Color) = (0.7,0.9,1,1)
        _GlintStrength("Artistic Highlight Strength", Range(0,5)) = 1.2
        _Sharpness("Highlight Sharpness", Range(2,256)) = 96
        _RimStrength("Artistic Rim Strength", Range(0,2)) = 0.2
        _LightDirection("Artistic Light Direction (World XYZ)", Vector) = (0.4,0.8,0.3,0)
    }

    HLSLINCLUDE
    #pragma target 4.5
    #pragma vertex Vert
    #pragma multi_compile_instancing
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassCommon.hlsl"
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/Material/NormalBuffer.hlsl"

    float _View, _Target, _Intensity, _Threshold, _Softness, _Darkening;
    float _TintStrength, _GlintStrength, _Sharpness, _RimStrength;
    float4 _Tint, _GlintColor, _LightDirection;

    float3 CoatingSafeNormalize(float3 value, float3 fallback)
    {
        float squareLength = dot(value, value);
        return squareLength > 0.000001 ? value * rsqrt(max(squareLength, 0.000001)) : fallback;
    }

    float4 RoughnessCoating(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        float weight = saturate(_Intensity) * saturate(_FadeValue);
        // Blend One SrcAlpha: RGB=0, alpha=1 leaves the camera untouched.
        if (_CustomPassInjectionPoint != CUSTOMPASSINJECTIONPOINT_BEFORE_POST_PROCESS || weight <= 0.0)
            return float4(0, 0, 0, 1);

        int2 size = max(int2(_ScreenSize.xy), int2(1, 1));
        uint2 pixel = (uint2)clamp((int2)input.positionCS.xy, int2(0, 0), size - 1);
        float depth = CustomPassLoadCameraDepth(pixel);
        #if UNITY_REVERSED_Z
            if (depth <= 0.0000001) return float4(0, 0, 0, 1);
        #else
            if (depth >= 0.9999999) return float4(0, 0, 0, 1);
        #endif

        NormalData data;
        DecodeFromNormalBuffer(pixel, data);
        float roughness = saturate(data.perceptualRoughness);
        float smoothMask = 1.0 - smoothstep(_Threshold - _Softness, _Threshold + _Softness, roughness);
        float selection = _Target < 0.5 ? smoothMask : (_Target < 1.5 ? 1.0 - smoothMask : 1.0);

        if (_View > 0.5)
        {
            float value = _View < 1.5 ? roughness : selection;
            // Replace the destination at full intensity; interpolate at partial intensity.
            return float4(value.xxx * weight, 1.0 - weight);
        }

        float3 normalWS = CoatingSafeNormalize(data.normalWS, float3(0, 1, 0));
        float3 lightWS = CoatingSafeNormalize(_LightDirection.xyz, float3(0, 1, 0));
        PositionInputs position = GetPositionInput(input.positionCS.xy, _ScreenSize.zw,
            depth, UNITY_MATRIX_I_VP, UNITY_MATRIX_V);
        float3 viewWS = GetWorldSpaceNormalizeViewDir(position.positionWS);
        float3 halfway = CoatingSafeNormalize(lightWS + viewWS, normalWS);
        float normalLight = saturate(dot(normalWS, lightWS));
        float normalHalf = saturate(dot(normalWS, halfway));
        float exponent = lerp(max(_Sharpness, 2.0), 4.0, roughness);
        float highlight = pow(normalHalf, exponent) * normalLight;
        // A rough surface receives a wider, weaker artificial highlight.
        highlight *= lerp(1.0, 0.15, roughness) * _GlintStrength;
        float facing = saturate(abs(dot(normalWS, viewWS)));
        float rim = pow(1.0 - facing, 3.0) * _RimStrength * (1.0 - roughness);
        float3 addition = max(_Tint.rgb, 0.0) * _TintStrength * 0.15;
        addition += max(_GlintColor.rgb, 0.0) * (highlight + rim);
        addition *= selection;
        float transmission = 1.0 - selection * saturate(_Darkening);

        // Hardware blending: newColor = addition + oldColor * transmission.
        // The shader never samples the camera color target.
        return float4(addition * weight, lerp(1.0, transmission, weight));
    }
    ENDHLSL

    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }
        Pass
        {
            Name "Roughness Coating"
            ZWrite Off
            ZTest Always
            Cull Off
            Blend One SrcAlpha
            ColorMask RGB
            HLSLPROGRAM
            #pragma fragment RoughnessCoating
            ENDHLSL
        }
    }
    Fallback Off
}
