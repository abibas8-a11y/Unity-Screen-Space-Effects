Shader "CustomPassEffects/05 Dream"
{
    Properties
    {
        [Enum(SoftDream,0,Psychedelic,1,Nightmare,2)] _Style("Style", Float) = 0
        _Intensity("Intensity", Range(0,1)) = 1
        _Speed("Animation Speed", Range(0,3)) = 0.5
        _Warp("Wave Distortion (Pixels)", Range(0,40)) = 4
        _Frequency("Wave Frequency", Range(1,50)) = 12
        _Twist("Twist (Radians)", Range(0,0.5)) = 0.04
        _Breathing("Breathing Zoom", Range(0,0.1)) = 0.015
        _RGBShift("Edge RGB Shift (Pixels)", Range(0,12)) = 1
        _BlurRadius("Soft Blur Radius (Pixels)", Range(0,12)) = 3
        _Softness("Soft Blur Strength", Range(0,1)) = 0.3
        _Glow("Soft Glow Strength", Range(0,1)) = 0.15
        _GlowThreshold("Soft Glow Threshold", Range(0,1)) = 0.65
        _DoubleVision("Double Image Strength", Range(0,1)) = 0.1
        _DoubleOffset("Double Image Offset (Pixels)", Range(0,30)) = 4
        _HueShift("Hue Rotation (Degrees)", Range(-180,180)) = 0
        _HueCycle("Animated Hue Rotation (Degrees)", Range(0,180)) = 8
        _Saturation("Saturation", Range(0,2)) = 1.05
        _Tint("Tint", Color) = (1,0.88,0.96,1)
        _TintStrength("Tint Strength", Range(0,1)) = 0.12
        _Pulse("Brightness Pulse", Range(0,0.3)) = 0.02
        _Vignette("Vignette", Range(0,1)) = 0.2
    }

    HLSLINCLUDE
    #pragma target 4.5
    #pragma vertex Vert
    #pragma multi_compile_instancing
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassCommon.hlsl"

    float _Style, _Intensity, _Speed, _Warp, _Frequency, _Twist, _Breathing, _RGBShift;
    float _BlurRadius, _Softness, _Glow, _GlowThreshold, _DoubleVision, _DoubleOffset;
    float _HueShift, _HueCycle, _Saturation, _TintStrength, _Pulse, _Vignette;
    float4 _Tint;

    float3 DreamPixel(int2 pixel)
    {
        int2 size = max(int2(_ScreenSize.xy), int2(1, 1));
        return CustomPassLoadCustomColor((uint2)clamp(pixel, int2(0, 0), size - 1)).rgb;
    }

    float3 DreamSample(float2 uv)
    {
        float2 p = saturate(uv) * _ScreenSize.xy - 0.5;
        int2 b = (int2)floor(p);
        float2 f = frac(p);
        return lerp(
            lerp(DreamPixel(b), DreamPixel(b + int2(1, 0)), f.x),
            lerp(DreamPixel(b + int2(0, 1)), DreamPixel(b + int2(1, 1)), f.x), f.y);
    }

    // Rotation around the neutral RGB axis; gray remains neutral.
    float3 DreamHue(float3 color, float angle)
    {
        float3 axis = float3(0.577350269, 0.577350269, 0.577350269);
        float s, c;
        sincos(angle, s, c);
        return color * c + cross(axis, color) * s + axis * dot(axis, color) * (1.0 - c);
    }

    float4 CopyScene(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        return float4(CustomPassLoadCameraColor((uint2)input.positionCS.xy, 0), 1);
    }

    float4 Dream(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        float3 original = DreamPixel((int2)input.positionCS.xy);
        float weight = saturate(_Intensity) * saturate(_FadeValue);
        if (weight <= 0.0) return float4(original, 1);

        bool psychedelic = _Style > 0.5 && _Style < 1.5;
        bool nightmare = _Style > 1.5;
        float warpScale = psychedelic ? 1.6 : (nightmare ? 1.2 : 1.0);
        float time = _Time.y * _Speed;
        float2 screenUV = input.positionCS.xy * _ScreenSize.zw;
        float aspect = _ScreenSize.x / max(_ScreenSize.y, 1.0);
        float2 p = (screenUV * 2.0 - 1.0) * float2(aspect, 1);
        float radius = length(p);
        float edge = smoothstep(0.1, 1.2, radius);
        float angle = sin(time * 0.7) * _Twist * edge * warpScale;
        float s, c;
        sincos(angle, s, c);
        p = float2(c * p.x - s * p.y, s * p.x + c * p.y);
        p /= 1.0 + _Breathing * (0.5 + 0.5 * sin(time * 1.1));
        float2 uv = p / float2(aspect, 1) * 0.5 + 0.5;
        float2 wave = float2(
            sin(uv.y * _Frequency + time * 1.3),
            cos(uv.x * _Frequency * 0.8 - time));
        uv += wave * _Warp * warpScale * lerp(0.25, 1.0, edge) * _ScreenSize.zw;

        float3 center = DreamSample(uv);
        float2 split = float2(_RGBShift * edge * _ScreenSize.z, 0);
        if (_RGBShift > 0.0)
        {
            center.r = DreamSample(uv + split).r;
            center.b = DreamSample(uv - split).b;
        }

        float3 soft = center;
        if (_BlurRadius > 0.0 && (_Softness > 0.0 || _Glow > 0.0))
        {
            float2 delta = _BlurRadius * _ScreenSize.zw;
            soft = DreamSample(uv) * 0.4;
            soft += DreamSample(uv + float2(delta.x, 0)) * 0.15;
            soft += DreamSample(uv - float2(delta.x, 0)) * 0.15;
            soft += DreamSample(uv + float2(0, delta.y)) * 0.15;
            soft += DreamSample(uv - float2(0, delta.y)) * 0.15;
        }
        float3 color = lerp(center, soft, saturate(_Softness));
        if (_DoubleVision > 0.0 && _DoubleOffset > 0.0)
        {
            float2 offset = float2(cos(time * 0.8), sin(time * 0.6)) * _DoubleOffset * _ScreenSize.zw;
            // Both images come from this frame's snapshot, with no temporal history.
            color = lerp(color, DreamSample(uv + offset), saturate(_DoubleVision) * 0.5);
        }

        float brightness = dot(soft, float3(0.2126, 0.7152, 0.0722));
        float highlight = smoothstep(_GlowThreshold, _GlowThreshold + 0.1, brightness);
        color += soft * highlight * _Glow;
        color = LinearToSRGB(saturate(color));
        float hueAngle = radians(_HueShift + sin(time * 0.5) * _HueCycle * (psychedelic ? 1.5 : 1.0));
        color = DreamHue(color, hueAngle);
        float luma = dot(color, float3(0.2126, 0.7152, 0.0722));
        color = lerp(luma.xxx, color, _Saturation * (nightmare ? 0.55 : 1.0));
        color *= lerp(float3(1, 1, 1), LinearToSRGB(saturate(_Tint.rgb)), saturate(_TintStrength));
        color *= 1.0 + sin(time * 1.2) * _Pulse;
        float vignette = smoothstep(0.2, 1.6, dot(screenUV * 2.0 - 1.0, screenUV * 2.0 - 1.0));
        color *= 1.0 - vignette * saturate(_Vignette);
        return float4(lerp(original, SRGBToLinear(saturate(color)), weight), 1);
    }
    ENDHLSL

    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }
        ZWrite Off
        ZTest Always
        Cull Off
        Blend Off
        ColorMask RGB
        Pass
        {
            Name "Copy Scene"
            HLSLPROGRAM
            #pragma fragment CopyScene
            ENDHLSL
        }
        Pass
        {
            Name "Dream"
            HLSLPROGRAM
            #pragma fragment Dream
            ENDHLSL
        }
    }
    Fallback Off
}
