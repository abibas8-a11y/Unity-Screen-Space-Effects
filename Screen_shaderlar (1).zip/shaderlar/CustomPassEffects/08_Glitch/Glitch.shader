Shader "CustomPassEffects/08 Glitch"
{
    Properties
    {
        [Enum(SignalTear,0,DataBlocks,1,RGBFault,2)] _Style("Style", Float) = 0
        _Intensity("Intensity", Range(0,1)) = 1
        _UpdateRate("Pattern Updates Per Second", Range(1,60)) = 12
        _Seed("Pattern Seed", Range(0,100)) = 0
        _Activity("Active Pattern Probability", Range(0,1)) = 1
        [Toggle] _Bursts("Intermittent Bursts", Float) = 0
        _BurstInterval("Burst Interval (Seconds)", Range(0.2,10)) = 2
        _BurstDuration("Burst Duration (Seconds)", Range(0.05,5)) = 0.5
        _RowDensity("Shifted Row Density", Range(0,1)) = 0.35
        _RowHeight("Row Height (Pixels)", Range(2,120)) = 18
        _RowShift("Row Shift (Pixels)", Range(0,240)) = 60
        _BlockDensity("Damaged Block Density", Range(0,1)) = 0.25
        _BlockSize("Block Size (Pixels)", Range(4,160)) = 40
        _BlockShift("Block Shift (Pixels)", Range(0,160)) = 20
        _Pixelation("Damaged Block Pixelation", Range(0,1)) = 0.45
        _PixelSize("Pixel Size (Pixels)", Range(1,24)) = 6
        _BlockLoss("Block Color Corruption", Range(0,1)) = 0.3
        _RGBShift("RGB Split (Pixels)", Range(0,60)) = 8
        _Invert("Block Inversion", Range(0,1)) = 0.15
        [Toggle] _Posterize("Posterize Damaged Blocks", Float) = 0
        [Enum(Four,4,Eight,8,Sixteen,16,ThirtyTwo,32)] _ColorSteps("Damaged Block Levels Per Channel", Float) = 8
        _Noise("Digital Noise", Range(0,0.5)) = 0.06
        _Scanlines("Scanline Strength", Range(0,1)) = 0.08
    }

    HLSLINCLUDE
    #pragma target 4.5
    #pragma vertex Vert
    #pragma multi_compile_instancing
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassCommon.hlsl"

    float _Style, _Intensity, _UpdateRate, _Seed, _Activity, _Bursts, _BurstInterval, _BurstDuration;
    float _RowDensity, _RowHeight, _RowShift, _BlockDensity, _BlockSize, _BlockShift;
    float _Pixelation, _PixelSize, _BlockLoss, _RGBShift, _Invert, _Posterize, _ColorSteps, _Noise, _Scanlines;

    float GlitchHash(float3 p)
    {
        p = frac(p * 0.1031);
        p += dot(p, p.yzx + 33.33);
        return frac((p.x + p.y) * p.z);
    }

    float3 GlitchPixel(int2 pixel)
    {
        int2 size = max(int2(_ScreenSize.xy), int2(1, 1));
        return CustomPassLoadCustomColor((uint2)clamp(pixel, int2(0, 0), size - 1)).rgb;
    }

    float3 GlitchSample(float2 uv)
    {
        float2 p = saturate(uv) * _ScreenSize.xy - 0.5;
        int2 b = (int2)floor(p);
        float2 f = frac(p);
        return lerp(
            lerp(GlitchPixel(b), GlitchPixel(b + int2(1, 0)), f.x),
            lerp(GlitchPixel(b + int2(0, 1)), GlitchPixel(b + int2(1, 1)), f.x), f.y);
    }

    float4 CopyScene(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        return float4(CustomPassLoadCameraColor((uint2)input.positionCS.xy, 0), 1);
    }

    float4 Glitch(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        float3 original = GlitchPixel((int2)input.positionCS.xy);
        float tick = floor(_Time.y * max(_UpdateRate, 1.0)) + _Seed * 13.7;
        float active = GlitchHash(float3(tick, 19.0, 7.0)) < saturate(_Activity) ? 1.0 : 0.0;
        if (_Bursts > 0.5)
        {
            float interval = max(_BurstInterval, 0.001);
            float elapsed = frac(_Time.y / interval) * interval;
            active *= elapsed < min(_BurstDuration, interval) ? 1.0 : 0.0;
        }
        float weight = saturate(_Intensity) * saturate(_FadeValue) * active;
        if (weight <= 0.0) return float4(original, 1);

        bool blocks = _Style > 0.5 && _Style < 1.5;
        bool rgb = _Style > 1.5;
        float2 pixel = input.positionCS.xy;
        float2 uv = pixel * _ScreenSize.zw;
        float row = floor(pixel.y / max(_RowHeight, 1.0));
        float rowMask = GlitchHash(float3(row, tick, 31.0)) < _RowDensity ? 1.0 : 0.0;
        float rowOffset = (GlitchHash(float3(row, tick, 63.0)) * 2.0 - 1.0)
            * _RowShift * rowMask * (blocks ? 0.3 : (rgb ? 0.5 : 1.0));
        float2 blockID = floor(pixel / max(_BlockSize, 1.0));
        float blockMask = GlitchHash(float3(blockID, tick + 11.0)) < _BlockDensity ? 1.0 : 0.0;
        float2 blockOffset = float2(
            GlitchHash(float3(blockID, tick + 23.0)),
            GlitchHash(float3(blockID, tick + 47.0))) * 2.0 - 1.0;
        blockOffset *= _BlockShift * blockMask * (blocks ? 1.8 : 1.0);
        uv += (float2(rowOffset, 0) + blockOffset) * _ScreenSize.zw;

        float pixelSize = max(_PixelSize, 1.0);
        float2 coarseUV = (floor(uv * _ScreenSize.xy / pixelSize) + 0.5) * pixelSize * _ScreenSize.zw;
        uv = lerp(uv, coarseUV, blockMask * saturate(_Pixelation));
        float splitRandom = GlitchHash(float3(row, tick, 97.0));
        float splitMask = rgb ? 1.0 : max(rowMask, blockMask);
        float2 split = float2(_RGBShift * (0.4 + splitRandom) * splitMask * (rgb ? 1.8 : 1.0) * _ScreenSize.z, 0);
        float3 color = GlitchSample(uv);
        if (_RGBShift > 0.0)
        {
            color.r = GlitchSample(uv + split).r;
            color.b = GlitchSample(uv - split).b;
        }
        color = LinearToSRGB(saturate(color));

        float blockValue = GlitchHash(float3(blockID, tick + 101.0));
        float3 corrupt = float3(blockValue,
            GlitchHash(float3(blockID, tick + 113.0)),
            GlitchHash(float3(blockID, tick + 127.0)));
        color = lerp(color, corrupt, blockMask * saturate(_BlockLoss));
        color = lerp(color, 1.0 - color, blockMask * saturate(_Invert));
        if (_Posterize > 0.5 && blockMask > 0.5)
        {
            float steps = max(floor(_ColorSteps + 0.5), 2.0) - 1.0;
            color = floor(saturate(color) * steps + 0.5) / steps;
        }
        float noise = GlitchHash(float3(floor(pixel), tick + 139.0)) * 2.0 - 1.0;
        color += noise * _Noise;
        float lines = 0.5 + 0.5 * cos(pixel.y * TWO_PI / 3.0);
        color *= 1.0 - lines * saturate(_Scanlines);
        return float4(lerp(original, SRGBToLinear(saturate(color)), weight), 1);
    }
    ENDHLSL

    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }
        ZWrite Off
        ZTest Always
        Cull Off
        Blend Off
        ColorMask RGB
        Pass
        {
            Name "Copy Scene"
            HLSLPROGRAM
            #pragma fragment CopyScene
            ENDHLSL
        }
        Pass
        {
            Name "Glitch"
            HLSLPROGRAM
            #pragma fragment Glitch
            ENDHLSL
        }
    }
    Fallback Off
}
