Shader "CustomPassEffects/09 Retro Horror"
{
    Properties
    {
        [Enum(PSXStyle,0,Camcorder,1,Monochrome,2)] _Style("Style", Float) = 0
        _Intensity("Intensity", Range(0,1)) = 1
        [Enum(H120,120,H180,180,H240,240,H360,360,H480,480)] _VirtualHeight("Virtual Height", Float) = 240
        _Pixelation("Pixelation Strength", Range(0,1)) = 1
        [Enum(Two,2,Four,4,Eight,8,Sixteen,16,ThirtyTwo,32,SixtyFour,64)] _Levels("Levels Per Channel / Gray", Float) = 16
        _Dither("Ordered Dither Strength", Range(0,1)) = 0.65
        [Enum(Bayer4x4,0,Bayer2x2,1)] _DitherPattern("Dither Pattern", Float) = 0
        _Contrast("Contrast", Range(0.5,2.5)) = 1.15
        _BlackPoint("Black Crush", Range(0,0.5)) = 0.08
        _Gamma("Brightness Gamma", Range(0.4,2.5)) = 0.95
        _Saturation("Saturation", Range(0,2)) = 0.75
        _Tint("Tint", Color) = (0.92,1,0.9,1)
        _TintStrength("Tint Strength", Range(0,1)) = 0.12
        _Vignette("Vignette Strength", Range(0,1)) = 0.65
        _VignetteStart("Vignette Start Radius", Range(0,1)) = 0.35
        _Grain("Film Grain", Range(0,0.25)) = 0.025
        _NoiseRate("Grain Updates Per Second", Range(1,60)) = 18
        _Scanlines("Scanline Strength", Range(0,1)) = 0.06
        _RGBShift("RGB Shift (Source Pixels)", Range(0,12)) = 0.6
        _Jitter("Camcorder Jitter (Source Pixels)", Range(0,12)) = 0.5
    }

    HLSLINCLUDE
    #pragma target 4.5
    #pragma vertex Vert
    #pragma multi_compile_instancing
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassCommon.hlsl"

    float _Style, _Intensity, _VirtualHeight, _Pixelation, _Levels, _Dither, _DitherPattern;
    float _Contrast, _BlackPoint, _Gamma, _Saturation, _TintStrength;
    float _Vignette, _VignetteStart, _Grain, _NoiseRate, _Scanlines, _RGBShift, _Jitter;
    float4 _Tint;

    float RetroHash(float3 p)
    {
        p = frac(p * 0.1031);
        p += dot(p, p.yzx + 33.33);
        return frac((p.x + p.y) * p.z);
    }

    float3 RetroPixel(int2 pixel)
    {
        int2 size = max(int2(_ScreenSize.xy), int2(1, 1));
        return CustomPassLoadCustomColor((uint2)clamp(pixel, int2(0, 0), size - 1)).rgb;
    }

    float RetroDither(uint2 pixel)
    {
        uint2 p = pixel & 3u;
        uint a = ((p.x & 1u) ^ (p.y & 1u)) * 2u + (p.y & 1u);
        uint b = (((p.x >> 1u) & 1u) ^ ((p.y >> 1u) & 1u)) * 2u + ((p.y >> 1u) & 1u);
        if (_DitherPattern > 0.5) return (float(a) + 0.5) / 4.0 - 0.5;
        return (float(a * 4u + b) + 0.5) / 16.0 - 0.5;
    }

    float4 CopyScene(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        return float4(CustomPassLoadCameraColor((uint2)input.positionCS.xy, 0), 1);
    }

    float4 RetroHorror(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        float3 original = RetroPixel((int2)input.positionCS.xy);
        float weight = saturate(_Intensity) * saturate(_FadeValue);
        if (weight <= 0.0) return float4(original, 1);

        bool camcorder = _Style > 0.5 && _Style < 1.5;
        bool mono = _Style > 1.5;
        float tick = floor(_Time.y * max(_NoiseRate, 1.0));
        float2 uv = input.positionCS.xy * _ScreenSize.zw;
        if (camcorder)
        {
            float row = floor(input.positionCS.y / 8.0);
            float jitter = (RetroHash(float3(row, tick, 7.0)) * 2.0 - 1.0) * _Jitter;
            uv.x += jitter * _ScreenSize.z;
        }
        uv = saturate(uv);
        float height = min(max(floor(_VirtualHeight + 0.5), 1.0), _ScreenSize.y);
        float width = min(max(floor(height * _ScreenSize.x / max(_ScreenSize.y, 1.0) + 0.5), 1.0), _ScreenSize.x);
        float2 gridSize = float2(width, height);
        float2 cell = min(floor(uv * gridSize), gridSize - 1.0);
        float2 blockUV = (cell + 0.5) / gridSize;
        float2 sourcePixel = lerp(uv, blockUV, saturate(_Pixelation)) * _ScreenSize.xy;
        float3 color = RetroPixel((int2)sourcePixel);
        if (_RGBShift > 0.0 && !mono)
        {
            color.r = RetroPixel((int2)floor(sourcePixel + float2(_RGBShift, 0))).r;
            color.b = RetroPixel((int2)floor(sourcePixel - float2(_RGBShift, 0))).b;
        }
        color = LinearToSRGB(saturate(color));
        color = saturate((color - 0.5) * _Contrast + 0.5);
        color = saturate((color - _BlackPoint) / max(1.0 - _BlackPoint, 0.001));
        color = pow(color, 1.0 / max(_Gamma, 0.001));
        float luma = dot(color, float3(0.2126, 0.7152, 0.0722));
        color = mono ? luma.xxx : saturate(lerp(luma.xxx, color, _Saturation));
        color *= lerp(float3(1, 1, 1), LinearToSRGB(saturate(_Tint.rgb)), saturate(_TintStrength));

        float2 centered = (input.positionCS.xy * _ScreenSize.zw) * 2.0 - 1.0;
        float vignette = smoothstep(_VignetteStart, 1.4, length(centered));
        color *= 1.0 - vignette * saturate(_Vignette);
        float noise = RetroHash(float3(cell, tick + 19.0)) * 2.0 - 1.0;
        color += noise * _Grain;
        float lines = 0.5 + 0.5 * cos(cell.y * PI);
        color *= 1.0 - lines * saturate(_Scanlines);

        // Grade first, then quantize so full intensity retains the selected levels.
        float steps = max(floor(_Levels + 0.5), 2.0) - 1.0;
        float threshold = RetroDither((uint2)cell) * saturate(_Dither);
        color = floor(saturate(color + threshold / steps) * steps + 0.5) / steps;
        return float4(lerp(original, SRGBToLinear(color), weight), 1);
    }
    ENDHLSL

    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }
        ZWrite Off
        ZTest Always
        Cull Off
        Blend Off
        ColorMask RGB
        Pass
        {
            Name "Copy Scene"
            HLSLPROGRAM
            #pragma fragment CopyScene
            ENDHLSL
        }
        Pass
        {
            Name "Retro Horror"
            HLSLPROGRAM
            #pragma fragment RetroHorror
            ENDHLSL
        }
    }
    Fallback Off
}
