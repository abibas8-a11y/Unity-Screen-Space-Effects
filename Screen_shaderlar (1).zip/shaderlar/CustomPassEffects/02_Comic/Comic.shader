Shader "CustomPassEffects/02 Comic"
{
    Properties
    {
        [Enum(ColorComic,0,Manga,1,Ink,2)] _Style("Style", Float) = 0
        [Enum(Two,2,Four,4,Eight,8,Sixteen,16,ThirtyTwo,32)] _Levels("Color / Gray Levels", Float) = 8
        _Saturation("Saturation", Range(0,2)) = 1.15
        _Contrast("Contrast", Range(0.5,2)) = 1.1
        _InkThreshold("Ink Black White Threshold", Range(0,1)) = 0.5
        _InkColor("Ink Color", Color) = (0.015,0.012,0.025,1)
        _PaperColor("Paper Tint", Color) = (1,0.96,0.86,1)
        _PaperStrength("Paper Tint Strength", Range(0,1)) = 0.15
        _OutlineWidth("Outline Width (Pixels)", Range(1,5)) = 1
        _OutlineThreshold("Outline Threshold", Range(0.005,1)) = 0.12
        _OutlineSoftness("Outline Softness", Range(0.001,0.5)) = 0.08
        _OutlineStrength("Outline Strength", Range(0,1)) = 1
        [Enum(Off,0,Lines,1,Crosshatch,2,Dots,3)] _HatchMode("Shadow Pattern", Float) = 2
        _HatchStrength("Shadow Pattern Strength", Range(0,1)) = 0.45
        _HatchSpacing("Pattern Spacing (Pixels)", Range(3,32)) = 8
        _HatchWidth("Pattern Width (Pixels)", Range(0.5,4)) = 1
        _HatchAngle("Pattern Angle (Degrees)", Range(0,180)) = 45
        _ShadowThreshold("Shadow Pattern Threshold", Range(0.05,1)) = 0.55
        _Intensity("Intensity", Range(0,1)) = 1
    }

    HLSLINCLUDE
    #pragma target 4.5
    #pragma vertex Vert
    #pragma multi_compile_instancing
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassCommon.hlsl"

    float _Style, _Levels, _Saturation, _Contrast, _InkThreshold;
    float4 _InkColor, _PaperColor;
    float _PaperStrength;
    float _OutlineWidth, _OutlineThreshold, _OutlineSoftness, _OutlineStrength;
    float _HatchMode, _HatchStrength, _HatchSpacing, _HatchWidth, _HatchAngle;
    float _ShadowThreshold, _Intensity;

    float LuminanceSRGB(float3 color)
    {
        return dot(color, float3(0.2126, 0.7152, 0.0722));
    }

    // Read a separate snapshot, never the camera target we are writing into.
    // Clamp all neighbors to the active viewport, including at screen edges.
    float3 ReadSnapshot(int2 pixel)
    {
        pixel = clamp(pixel, int2(0, 0), max(int2(_ScreenSize.xy) - 1, int2(0, 0)));
        return CustomPassLoadCustomColor((uint2)pixel).rgb;
    }

    float ReadLuma(int2 pixel)
    {
        return LuminanceSRGB(LinearToSRGB(saturate(ReadSnapshot(pixel))));
    }

    float Outline(int2 pixel)
    {
        int w = max(1, (int)floor(_OutlineWidth + 0.5));
        float tl = ReadLuma(pixel + int2(-w, -w));
        float tc = ReadLuma(pixel + int2(0, -w));
        float tr = ReadLuma(pixel + int2(w, -w));
        float ml = ReadLuma(pixel + int2(-w, 0));
        float mr = ReadLuma(pixel + int2(w, 0));
        float bl = ReadLuma(pixel + int2(-w, w));
        float bc = ReadLuma(pixel + int2(0, w));
        float br = ReadLuma(pixel + int2(w, w));
        float gx = -tl - 2.0 * ml - bl + tr + 2.0 * mr + br;
        float gy = -tl - 2.0 * tc - tr + bl + 2.0 * bc + br;
        float gradient = length(float2(gx, gy)) * 0.25;
        return smoothstep(_OutlineThreshold, _OutlineThreshold + max(_OutlineSoftness, 0.001), gradient);
    }

    float PatternLine(float coordinate, float spacing, float width)
    {
        float distanceToLine = abs(frac(coordinate / spacing + 0.5) - 0.5) * spacing;
        float aa = max(fwidth(coordinate) * 0.5, 0.5);
        return 1.0 - smoothstep(width * 0.5, width * 0.5 + aa, distanceToLine);
    }

    float ShadowPattern(float2 pixel, float luminance)
    {
        if (_HatchMode < 0.5 || _HatchStrength <= 0.0) return 0;
        float angle = radians(_HatchAngle);
        float s, c;
        sincos(angle, s, c);
        float2 p = float2(c * pixel.x - s * pixel.y, s * pixel.x + c * pixel.y);
        float spacing = max(_HatchSpacing, 3.0);
        float width = min(_HatchWidth, spacing * 0.45);
        float shadow = 1.0 - smoothstep(0.0, max(_ShadowThreshold, 0.001), luminance);
        float pattern = PatternLine(p.x, spacing, width);
        if (_HatchMode > 1.5 && _HatchMode < 2.5)
        {
            float secondLine = PatternLine(p.y, spacing, width);
            pattern = max(pattern, secondLine * smoothstep(0.3, 0.8, shadow));
        }
        else if (_HatchMode > 2.5)
        {
            float2 cell = (frac(p / spacing + 0.5) - 0.5) * spacing;
            float radius = min(width + shadow * spacing * 0.25, spacing * 0.45);
            float aa = max(length(fwidth(p)) * 0.5, 0.5);
            pattern = 1.0 - smoothstep(radius, radius + aa, length(cell));
        }
        return saturate(pattern * shadow * _HatchStrength);
    }

    float4 CopyScene(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        return float4(CustomPassLoadCameraColor((uint2)input.positionCS.xy, 0), 1);
    }

    float4 Comic(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        int2 pixel = (int2)input.positionCS.xy;
        float3 original = ReadSnapshot(pixel);
        float weight = saturate(_Intensity) * saturate(_FadeValue);
        if (weight <= 0.0) return float4(original, 1);

        // SDR: after tone mapping. Quantize perceptual values, output linear RGB.
        float3 color = LinearToSRGB(saturate(original));
        color = saturate((color - 0.5) * _Contrast + 0.5);
        float luminance = LuminanceSRGB(color);
        float steps = max(floor(_Levels + 0.5), 2.0) - 1.0;
        if (_Style < 0.5)
        {
            color = saturate(lerp(luminance.xxx, color, _Saturation));
            color = floor(color * steps + 0.5) / steps;
        }
        else if (_Style < 1.5)
        {
            float gray = floor(luminance * steps + 0.5) / steps;
            color = gray.xxx;
        }
        else
        {
            float bw = step(_InkThreshold, luminance);
            color = bw.xxx;
        }

        // Material Color properties arrive in linear space in a linear project.
        float3 ink = LinearToSRGB(saturate(_InkColor.rgb));
        float3 paper = LinearToSRGB(saturate(_PaperColor.rgb));
        color *= lerp(float3(1, 1, 1), paper, saturate(_PaperStrength));
        color = lerp(color, ink, ShadowPattern(input.positionCS.xy, luminance));
        if (_OutlineStrength > 0.0)
            color = lerp(color, ink, Outline(pixel) * saturate(_OutlineStrength));
        return float4(lerp(original, SRGBToLinear(saturate(color)), weight), 1);
    }
    ENDHLSL

    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }
        ZWrite Off
        ZTest Always
        Cull Off
        Blend Off
        ColorMask RGB

        Pass
        {
            Name "Copy Scene"
            HLSLPROGRAM
            #pragma fragment CopyScene
            ENDHLSL
        }
        Pass
        {
            Name "Comic"
            HLSLPROGRAM
            #pragma fragment Comic
            ENDHLSL
        }
    }
    Fallback Off
}
