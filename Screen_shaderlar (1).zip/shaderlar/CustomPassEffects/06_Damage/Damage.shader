Shader "CustomPassEffects/06 Damage"
{
    Properties
    {
        [Enum(DirectionalHit,0,LowHealth,1,Poison,2)] _Style("Style", Float) = 0
        _Damage("Damage Amount", Range(0,1)) = 0.65
        _Intensity("Intensity", Range(0,1)) = 1
        _HitAngle("Hit Direction (0 Right, 90 Up)", Range(0,360)) = 0
        _DirectionSpread("Direction Spread", Range(0.05,1)) = 0.65
        _EdgeStart("Edge Start", Range(0,0.95)) = 0.35
        _EdgeSoftness("Edge Softness", Range(0.02,1)) = 0.5
        _DamageColor("Damage Tint", Color) = (0.65,0.025,0.015,1)
        _TintStrength("Edge Tint Strength", Range(0,1)) = 0.7
        _Darkening("Edge Darkening", Range(0,1)) = 0.35
        _Desaturation("Desaturation", Range(0,1)) = 0.35
        _RGBShift("Edge RGB Shift (Pixels)", Range(0,16)) = 2
        _BlurRadius("Edge Blur Radius (Pixels)", Range(0,12)) = 2
        _BlurStrength("Edge Blur Strength", Range(0,1)) = 0.25
        _ShakePixels("Screen Shake (Pixels)", Range(0,12)) = 0.6
        _ShakeSpeed("Shake Speed", Range(0,40)) = 18
        _PulseStrength("Heartbeat Pulse Strength", Range(0,1)) = 0.3
        _PulseBPM("Heartbeat BPM", Range(30,180)) = 70
        [Toggle] _PreviewHit("Loop Hit Preview", Float) = 0
        _PreviewInterval("Preview Interval (Seconds)", Range(0.5,5)) = 2
        _HitDecay("Preview Hit Decay", Range(1,15)) = 5
    }

    HLSLINCLUDE
    #pragma target 4.5
    #pragma vertex Vert
    #pragma multi_compile_instancing
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassCommon.hlsl"

    float _Style, _Damage, _Intensity, _HitAngle, _DirectionSpread, _EdgeStart, _EdgeSoftness;
    float4 _DamageColor;
    float _TintStrength, _Darkening, _Desaturation, _RGBShift, _BlurRadius, _BlurStrength;
    float _ShakePixels, _ShakeSpeed, _PulseStrength, _PulseBPM, _PreviewHit, _PreviewInterval, _HitDecay;

    float3 DamagePixel(int2 pixel)
    {
        int2 size = max(int2(_ScreenSize.xy), int2(1, 1));
        return CustomPassLoadCustomColor((uint2)clamp(pixel, int2(0, 0), size - 1)).rgb;
    }

    float3 DamageSample(float2 uv)
    {
        float2 p = saturate(uv) * _ScreenSize.xy - 0.5;
        int2 b = (int2)floor(p);
        float2 f = frac(p);
        return lerp(
            lerp(DamagePixel(b), DamagePixel(b + int2(1, 0)), f.x),
            lerp(DamagePixel(b + int2(0, 1)), DamagePixel(b + int2(1, 1)), f.x), f.y);
    }

    float DamageHeartbeat(float time)
    {
        float phase = frac(time * max(_PulseBPM, 1.0) / 60.0);
        float a = (phase - 0.15) * 24.0;
        float b = (phase - 0.36) * 28.0;
        return saturate(exp(-a * a) + 0.55 * exp(-b * b));
    }

    float4 CopyScene(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        return float4(CustomPassLoadCameraColor((uint2)input.positionCS.xy, 0), 1);
    }

    float4 Damage(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        float3 original = DamagePixel((int2)input.positionCS.xy);
        float amount = saturate(_Damage);
        float time = _Time.y;
        if (_PreviewHit > 0.5)
        {
            float elapsed = frac(time / max(_PreviewInterval, 0.1)) * max(_PreviewInterval, 0.1);
            amount *= exp(-elapsed * max(_HitDecay, 0.0));
        }
        amount *= lerp(1.0, lerp(0.45, 1.0, DamageHeartbeat(time)), saturate(_PulseStrength));
        float weight = saturate(_Intensity) * saturate(_FadeValue) * amount;
        if (weight <= 0.0) return float4(original, 1);

        bool directional = _Style < 0.5;
        bool poison = _Style > 1.5;
        float2 screenUV = input.positionCS.xy * _ScreenSize.zw;
        float2 p = screenUV * 2.0 - 1.0;
        #if UNITY_UV_STARTS_AT_TOP
            p.y = -p.y;
        #endif
        float radius = length(p);
        float edge = smoothstep(_EdgeStart, _EdgeStart + max(_EdgeSoftness, 0.001), radius);
        float directionMask = 1.0;
        if (directional)
        {
            float s, c;
            sincos(radians(_HitAngle), s, c);
            float alignment = dot(p / max(radius, 0.0001), float2(c, s));
            directionMask = smoothstep(1.0 - 2.0 * _DirectionSpread, 1.0, alignment);
        }
        float mask = saturate(edge * directionMask);
        float2 shake = float2(sin(time * _ShakeSpeed * 1.17), sin(time * _ShakeSpeed * 1.63));
        float2 uv = screenUV + shake * _ShakePixels * amount * _ScreenSize.zw;
        if (poison)
        {
            float2 wave = float2(sin(screenUV.y * 17.0 + time), cos(screenUV.x * 13.0 - time * 0.8));
            uv += wave * _ShakePixels * amount * edge * _ScreenSize.zw;
        }
        float3 color = DamageSample(uv);
        if (_RGBShift > 0.0)
        {
            float2 split = float2(_RGBShift * mask * amount * _ScreenSize.z, 0);
            color.r = DamageSample(uv + split).r;
            color.b = DamageSample(uv - split).b;
        }
        if (_BlurRadius > 0.0 && _BlurStrength > 0.0)
        {
            float2 delta = _BlurRadius * _ScreenSize.zw;
            float3 soft = DamageSample(uv) * 0.4;
            soft += DamageSample(uv + float2(delta.x, 0)) * 0.15;
            soft += DamageSample(uv - float2(delta.x, 0)) * 0.15;
            soft += DamageSample(uv + float2(0, delta.y)) * 0.15;
            soft += DamageSample(uv - float2(0, delta.y)) * 0.15;
            color = lerp(color, soft, mask * saturate(_BlurStrength));
        }

        float luma = dot(color, float3(0.2126, 0.7152, 0.0722));
        color = lerp(color, luma.xxx, saturate(_Desaturation));
        color *= 1.0 - mask * saturate(_Darkening);
        // Poison shifts the selected tint toward green; it remains user-adjustable.
        float3 tint = saturate(_DamageColor.rgb);
        if (poison) tint = tint.brg;
        color = lerp(color, tint, mask * saturate(_TintStrength));
        return float4(lerp(original, color, weight), 1);
    }
    ENDHLSL

    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }
        ZWrite Off
        ZTest Always
        Cull Off
        Blend Off
        ColorMask RGB
        Pass
        {
            Name "Copy Scene"
            HLSLPROGRAM
            #pragma fragment CopyScene
            ENDHLSL
        }
        Pass
        {
            Name "Damage"
            HLSLPROGRAM
            #pragma fragment Damage
            ENDHLSL
        }
    }
    Fallback Off
}
