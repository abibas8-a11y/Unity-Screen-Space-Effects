Shader "CustomPassEffects/07 Sonar"
{
    Properties
    {
        [Enum(Classic,0,Technical,1,DarkRadar,2)] _Style("Style", Float) = 0
        _Intensity("Intensity", Range(0,1)) = 1
        [Toggle] _AutoScan("Auto Scan", Float) = 1
        _Radius("Manual Radius", Range(0,300)) = 15
        _Speed("Scan Speed (Units Per Second)", Range(0.1,100)) = 10
        _MaxRange("Maximum Range", Range(1,300)) = 60
        _RepeatDelay("Repeat Delay (Seconds)", Range(0,10)) = 1
        _RingWidth("Ring Half Width (World Units)", Range(0.05,10)) = 0.7
        _TrailLength("Trail Length (World Units)", Range(0,50)) = 6
        _TrailStrength("Trail Strength", Range(0,1)) = 0.35
        _ScanColor("Scan Color", Color) = (0.05,1,0.65,1)
        _Brightness("Scan Brightness", Range(0,5)) = 1.3
        _SceneVisibility("Scene Visibility", Range(0,1)) = 0.35
        _BackgroundColor("Background Color", Color) = (0.005,0.015,0.025,1)
        _EdgeStrength("Surface Edge Highlight", Range(0,3)) = 1
        _EdgeThreshold("Relative Depth Edge Threshold", Range(0.001,0.3)) = 0.025
        _GridStrength("Grid Strength", Range(0,1)) = 0.3
        _GridSize("Grid Spacing (World Units)", Range(0.25,10)) = 1
        _GridWidth("Grid Line Half Width (World Units)", Range(0.005,0.2)) = 0.025
        _Scanlines("Screen Scanline Strength", Range(0,1)) = 0.08
    }

    HLSLINCLUDE
    #pragma target 4.5
    #pragma vertex Vert
    #pragma multi_compile_instancing
    #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassCommon.hlsl"

    float _Style, _Intensity, _AutoScan, _Radius, _Speed, _MaxRange, _RepeatDelay;
    float _RingWidth, _TrailLength, _TrailStrength, _Brightness, _SceneVisibility;
    float _EdgeStrength, _EdgeThreshold, _GridStrength, _GridSize, _GridWidth, _Scanlines;
    float4 _ScanColor, _BackgroundColor;

    float3 SonarPixel(int2 pixel)
    {
        int2 size = max(int2(_ScreenSize.xy), int2(1, 1));
        return CustomPassLoadCustomColor((uint2)clamp(pixel, int2(0, 0), size - 1)).rgb;
    }

    float4 CopyScene(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        return float4(CustomPassLoadCameraColor((uint2)input.positionCS.xy, 0), 1);
    }

    float4 Sonar(Varyings input) : SV_Target
    {
        UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
        float3 original = SonarPixel((int2)input.positionCS.xy);
        float weight = saturate(_Intensity) * saturate(_FadeValue);
        if (weight <= 0.0) return float4(original, 1);

        bool technical = _Style > 0.5 && _Style < 1.5;
        bool radar = _Style > 1.5;
        float3 background = saturate(_BackgroundColor.rgb);
        float visibility = saturate(_SceneVisibility) * (radar ? 0.25 : 1.0);
        float3 color = lerp(background, original, visibility);

        float depth = CustomPassLoadCameraDepth((uint2)input.positionCS.xy);
        // Skip sky / cleared depth: reconstructing infinite far depth can be singular.
        #if UNITY_REVERSED_Z
            bool sky = depth <= 0.0000001;
        #else
            bool sky = depth >= 0.9999999;
        #endif
        if (sky) return float4(lerp(original, color, weight), 1);

        PositionInputs position = GetPositionInput(input.positionCS.xy, _ScreenSize.zw,
            depth, UNITY_MATRIX_I_VP, UNITY_MATRIX_V);
        // Both values use HDRP's current camera-relative coordinate convention.
        float distanceFromCamera = length(position.positionWS - GetCurrentViewPosition());

        float range = max(_MaxRange, 0.001);
        float radius = clamp(_Radius, 0.0, range);
        float active = 1.0;
        if (_AutoScan > 0.5)
        {
            float speed = max(_Speed, 0.001);
            float duration = range / speed;
            float cycle = duration + max(_RepeatDelay, 0.0);
            float elapsed = frac(_Time.y / cycle) * cycle;
            radius = min(elapsed * speed, range);
            active = elapsed <= duration ? 1.0 : 0.0;
        }

        float delta = radius - distanceFromCamera;
        float footprint = max(fwidth(distanceFromCamera), 0.001);
        float width = max(_RingWidth, 0.001);
        float ring = 1.0 - smoothstep(width, width + footprint, abs(delta));
        float trail = 0.0;
        if (_TrailLength > 0.0)
        {
            float behind = smoothstep(0.0, footprint, delta);
            trail = behind * saturate(1.0 - delta / _TrailLength) * saturate(_TrailStrength);
        }
        float scan = max(ring, trail) * active;
        scan *= 1.0 - smoothstep(range, range + footprint, distanceFromCamera);

        float relativeGradient = length(float2(ddx(distanceFromCamera), ddy(distanceFromCamera)))
            / max(distanceFromCamera, 0.1);
        float edges = smoothstep(_EdgeThreshold, _EdgeThreshold * 2.0, relativeGradient);
        float detail = edges * _EdgeStrength;
        if (technical && _GridStrength > 0.0)
        {
            float3 world = GetAbsolutePositionWS(position.positionWS);
            float spacing = max(_GridSize, 0.001);
            float2 cell = abs(frac(world.xz / spacing + 0.5) - 0.5) * spacing;
            float gridDistance = min(cell.x, cell.y);
            float lineWidth = min(_GridWidth, spacing * 0.25);
            float grid = 1.0 - smoothstep(lineWidth, lineWidth + max(fwidth(gridDistance), 0.001), gridDistance);
            detail += grid * _GridStrength;
        }
        float3 scanColor = max(_ScanColor.rgb, 0.0);
        color += scanColor * scan * _Brightness * (0.35 + detail);
        float lines = 0.5 + 0.5 * cos(input.positionCS.y * TWO_PI / 3.0);
        color *= 1.0 - lines * saturate(_Scanlines);
        return float4(lerp(original, saturate(color), weight), 1);
    }
    ENDHLSL

    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }
        ZWrite Off
        ZTest Always
        Cull Off
        Blend Off
        ColorMask RGB
        Pass
        {
            Name "Copy Scene"
            HLSLPROGRAM
            #pragma fragment CopyScene
            ENDHLSL
        }
        Pass
        {
            Name "Sonar"
            HLSLPROGRAM
            #pragma fragment Sonar
            ENDHLSL
        }
    }
    Fallback Off
}
